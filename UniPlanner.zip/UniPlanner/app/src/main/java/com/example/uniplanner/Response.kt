package com.example.uniplanner

class ResponseClass {
    var greetings: String? = null

    constructor(greetings: String?) {
        this.greetings = greetings
    }

    constructor() {}
}